<?php session_start();?>




<body>

  <?php include './modelo/conexion_bd.php'; 
      include ("./includes/header.php");
      include("./includes/sidebar.php");
  ?>


  <div class="col-8 bg-light">
    <div class="card-header">
        <div class="card-tools">
          <a id="backupButton" class="btn btn-block btn-sm btn-default btn-flat border-primary" href="#"><i class="fa fa-plus"></i> Respaldar</a>
        </div>
    </div>
      <div class="card-body">
        <table class="table table-bordered table-striped" id="list">
          <thead>
            <tr>
              <th class="text-center">#</th>
              <th>Nombre</th>
              <th>Fecha</th>
              <th>Acción</th>
            </tr>
          </thead>
          <tbody>
          <?php
          require './modelo/conexion_bd.php';
          $sql = "SELECT * from respaldos";
          $result = mysqli_query($conexion, $sql);

          if (!$result) {
            die('Error al ejecutar la consulta: ' . mysqli_error($conexion));
          }
          while ($mostrar = mysqli_fetch_array($result)) {
          ?>
            <tr>
      <td class="text-center"><?php echo $mostrar['idr'] ?></td>
      <td class="text-center"><?php echo $mostrar['nombre']; ?></td>
      <td class="text-center"><?php echo date("d/m/Y g:i a", strtotime($mostrar['fecha'])); ?></td>
      <td class="text-center">
        <div class="row">
        <form class="form col-sm restaurarForm" method="post">
          <input type="hidden" name="idr" value="<?php echo $mostrar['idr']; ?>">
          <button class="btn btn-info btn-flat" type="submit" name="restaurar" data-toggle="tooltip" data-placement="left" title="Restaurar respaldo"><i class='fa fa-upload'></i></button>
        </form>

          <form class="form col-sm" action="./controlador/eliminarbd.php" method="post">
            <input type="hidden" name="idr" value="<?php echo $mostrar['idr']; ?>">
            <button class="btn btn-danger btn-flat" type="submit" name="eliminar" data-toggle="tooltip" data-placement="left" title="Eliminar respaldo" onclick="return confirm('¿Está seguro que quiere eliminar este respaldo?');"><i class='fa fa-trash'></i></button>
          </form>
        </div>
      </td>
    </tr>
          <?php } ?>

          </tbody>
        </table>
    </div>
  </div>

  <?php include ("./includes/footer.php")?>  

  <script>
document.getElementById('backupButton').addEventListener('click', function(event) {
      event.preventDefault();

      fetch('controlador/respaldobd.php')
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            Swal.fire({
              title: 'Respaldo Exitoso!',
              text: data.message,
              icon: 'success',
              confirmButtonText: 'Aceptar'
            }).then(() => {
              // Recargar la página para reflejar los nuevos datos
              window.location.reload();
            });
          } else {
            Swal.fire({
              title: 'Error',
              text: data.message,
              icon: 'error',
              confirmButtonText: 'Aceptar'
            });
          }
        })
        .catch(error => {
          Swal.fire({
            title: 'Error',
            text: 'Hubo un problema al realizar el respaldo.',
            icon: 'error',
            confirmButtonText: 'Aceptar'
          });
        });
    });


    // formulario de restauración 
    document.addEventListener('DOMContentLoaded', function () {
  console.log("El script está cargado y ejecutándose.");

  // Obtener todos los formularios con la clase 'restaurarForm'
  const forms = document.querySelectorAll('.restaurarForm');

  // Iterar sobre cada formulario y agregarle el event listener
  forms.forEach(form => {
  form.addEventListener('submit', (e) => {
    e.preventDefault();  // Evitar que el formulario se envíe de forma tradicional
    const formData = new FormData(form);
    
    // Verificar los datos del FormData
    console.log("Datos enviados:");
for (let [key, value] of formData.entries()) {
  console.log(`${key}: ${value}`);
}
  // Ver qué datos están siendo enviados
    
    fetch('controlador/restaurarbd.php', {
      method: 'POST',
      body: formData
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        Swal.fire({
          icon: 'success',
          title: 'Restauración Exitosa',
          text: data.message
        });
      } else {
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: data.message
        });
      }
    })
    .catch(error => {
      console.log(error);
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Hubo un problema con la solicitud.'
      });
    });
  });
});

});


</script>

</body>
</html>
