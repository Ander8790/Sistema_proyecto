$(document).ready(function () {
    $('#list').DataTable({
      language: {
        url: "https://cdn.datatables.net/plug-ins/1.11.5/i18n/es-ES.json" // Traducción al español
      },
      pageLength: 5, // Número de filas por página
      lengthChange: true, // Opciones para cambiar el tamaño de página
      responsive: true // Diseño responsivo
    });
  });
  