
<?php
include 'modelo/conexion_bd.php';

// Obtener el filtro de tiempo (semanal o mensual)
$filtro = isset($_GET['filtro']) ? $_GET['filtro'] : 'semanal';

// Calcular el rango de fechas según el filtro seleccionado
if ($filtro == 'semanal') {
    $fecha_inicio = date('Y-m-d', strtotime('-7 days'));
} else {
    $fecha_inicio = date('Y-m-d', strtotime('-30 days'));
}
$fecha_fin = date('Y-m-d');

// Consultar la base de datos para obtener los informes de entrada y salida
$query = "SELECT * FROM movimientos_equipos WHERE fecha BETWEEN '$fecha_inicio' AND '$fecha_fin'";
$resultado = $conexion->query($query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informes de Equipos</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h3 class="text-center">Informe de Equipos (<?php echo ucfirst($filtro); ?>)</h3>
        <form method="GET" class="text-center mb-3">
            <select name="filtro" onchange="this.form.submit()" class="form-select w-25 d-inline-block">
                <option value="semanal" <?php echo $filtro == 'semanal' ? 'selected' : ''; ?>>Semanal</option>
                <option value="mensual" <?php echo $filtro == 'mensual' ? 'selected' : ''; ?>>Mensual</option>
            </select>
        </form>
        <table class="table table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Equipo</th>
                    <th>Tipo de Movimiento</th>
                    <th>Fecha</th>
                    <th>Descripción</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $resultado->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['equipo']; ?></td>
                    <td><?php echo $row['tipo_movimiento']; ?></td>
                    <td><?php echo $row['fecha']; ?></td>
                    <td><?php echo $row['descripcion']; ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>
