<!DOCTYPE html>
<html lang="en">
<?php
session_start();
include('./modelo/conexion_bd.php');
?>

<head>
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">

	<title>Recuperacion de contraseña</title>
	<?php include('includes/header.php'); ?>
	<?php
	if (isset($_SESSION['login_id']))
		header("location:index.php?page=home");

	?>
</head>
<style>
	body {
		width: 100%;
		height: calc(100%);
		position: fixed;
		top: 0;
		left: 0;
		background-image: url(./assets/img/fondoisp.jpg) !important;
    	background-size: cover;
        background-repeat: no-repeat;
	}

	main#main {
		width: 100%;
		height: calc(100%);
		display: flex;
	}
</style>

<body class="bg-info">
    <main id="main">
        <div class="align-self-center w-100">
            <!-- <h4 class="text-black text-center"><b>Sistema de Encuesta en Línea</b></h4> -->
            <div id="login-center" class="row justify-content-center">
                <div class="card col-md-4">
                    <!-- LOGO-->
                    <img class="avatar" src="./assets/img/iconisp.png" alt="Logo del isp" style="width: 100px; height: 100px; border-radius:50%; margin-left: auto; margin-right: auto;">
                    <h4 class="text-black text-center">
                        <b style="color: black;">
                            Recuperacion de contraseña
                        </b>
                    </h4>
                    <div class="card-body">
                        <form id="login-form" class="needs-validation" action="pregunta.php" method="post" onsubmit="return validarUser()" novalidate>
                            <div class="form-group">
                                <label for="username" class="control-label text-dark">Usuario</label>
                                <input type="text" id="user" name="username" class="form-control form-control-sm" required>
                            </div>
                            <center>
                                <button class="btn-sm btn-block btn-wave col-md-4 btn-primary">Ingresar</button>
                            </center>
                            <br>
                            <br>
                            <button type="button" class="btn-sm btn-block btn-wave col-md-4 btn-warning" onclick="window.location.href='index.php'">Volver al inicio
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>
    <script>
        function validarUser() {
            var user = document.getElementById('user').value;
            if (user.trim() === '') {
                alert('Por favor, ingrese su Usuario.');
                return false; // Evita enviar el formulario si el correo está vacío
            }
            return true; // Permite enviar el formulario si el correo no está vacío
        }
    </script>
</body>
