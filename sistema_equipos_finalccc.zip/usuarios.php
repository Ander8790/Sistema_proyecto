<?php
    session_start();

    if (!isset($_SESSION['usuario'])) {
      // Si no hay sesión, redirigir al login
      header('Location: login.php');
      exit(); // Asegura que el código posterior no se ejecute
  }
  


    include ("./modelo/conexion_bd.php");
    include ("./includes/header.php");
    include("./includes/sidebar.php");
?>

<body>
    

<div class="col-8 bg-light">
  <div class="card-header">
    <div class="card-tools">
			<a class="btn btn-block btn-sm btn-default btn-flat border-primary" href="./crear_usuario.php"><i class="fa fa-plus"></i> Agregar Nuevo Usuario</a>
		</div>
  </div>
  <div class="card-body">
  <table class="table table-bordered table-striped" id="list">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">NOMBRE</th>
      <th scope="col">USUARIO</th>
      <th scope="col">CEDULA</th>
      <th scope="col">NIVEL</th>
      <th scope="col">ACCIÓN</th>
    </tr>
  </thead>
  <tbody>

  <?php

  $i=1;
  $query = ("SELECT *,concat(apellido,', ', nombre) as name FROM usuarios order by concat(apellido, ', ',  nombre) asc");
  $result = $conexion->query($query);

  if ($result === false) {
    die("Error en la consulta: " . $conexion->error);
}

  while ($row = $result->fetch_assoc()) :
  ?>


    <tr>
      <th scope="row"> <?php echo $i++ ?> </th>
      <td> <?php echo ucwords($row['name'])?> </td>
      <td> <?php echo $row['username']?> </td>
      <td> <?php echo $row['cedula']?> </td>
      <td>
        <?php
        if ($row['id_rol'] == 1) {
          echo "Administrador";
        } elseif ($row['id_rol'] == 2) {
          echo "Odontólogo";
        } elseif ($row['id_rol'] == 3) {
          echo "Secretaria";
        } else {
          echo "Desconocido";
        }
        ?>
      </td>
      <td class="text-center"> 
      <!-- <button class='btn btn-warning btn-sm' type="submit">Editar</button>
      <button class='btn btn-danger btn-sm' type="submit">Eliminar</button> -->


<!-- editar -->
<a href="editar.php?id=<?php echo $row['id_user']?>" class="btn btn-warning btn-sm mb-1"><i class='bx bx-edit-alt'></i></a>

<!-- eliminar -->
<form action="/controlador/procesar_eliminar.php" method="post">
    <input type="hidden" value="<?php echo $row['id_user']; ?>" name="txtID" readonly>
    <button class="btn btn-danger btn-sm" type="submit" name="btnEliminar">
        <i class='bx bx-trash'></i>
    </button>
</form>




      </td>
    </tr>
    <?php endwhile?>
  </tbody>
</table>
</div>

</div>

<?php
include ("./includes/footer.php")
?>

</body>
</html>