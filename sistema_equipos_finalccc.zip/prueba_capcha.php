<?php
	include "./modelo/conexion_bd.php";
	include "./controlador/controlador_login.php";
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de citas</title>
	<link rel="stylesheet" href="./assets/css/styles.css">
	<link rel="shortcut icon" href="./assets/img/iconisp.png">
	<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body>
	<div class="formulario">
		<img src="./assets/img/iconisp.png" alt="logo_isp">
		<h1>Inicio de sesión</h1>
		<form action="/controlador/procesar_prueba.php" method="post">
			

			<div class="input-box">
				<!-- <label for="usuario">Usuario</label> -->
				<input type="text" name="usuario" placeholder="username">
				<i class='bx bx-user'></i>
			</div>
			<div class="input-box">
				<!-- <label for="passw">Contraseña</label> -->
				<input type="password" name="password" placeholder="password">
				<i class='bx bxs-lock-alt' ></i>
			</div>
            <div class="mb-4">
                <label for="codigo" >Código de Verificación</label>
                <input type="text" name="codigo" class="form-control">
            </div>

            <div class="mb-3">
                <img src="funcs/genera_codigo.php" alt="Codigo captcha" id="img-codigo">
                <button type="button" class="btn btn-secondary btn-sm" id="regenera"><i class='bx bx-refresh'></i></button>
            </div>

			<div class="forgot-pss">
				<a href="/prueba_capcha.php">Olvidaste tu contraseña?</a>
			</div>
			
			<input type="submit" class="btn" name="btn-login" value="Ingresar">
		</form>
	</div>

    <script>
    const imgCodigo = document.getElementById('img-codigo');
    const btnGenera = document.getElementById('regenera');

    btnGenera.addEventListener('click', generaCodigo, false);

    function generaCodigo() {
        const url = 'funcs/genera_codigo.php';

        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.blob(); // Corregido aquí
            })
            .then(data => {
                if (data) {
                    imgCodigo.src = URL.createObjectURL(data);
                }
            })
            .catch(error => {
                console.error('Error al generar el código:', error);
            });
    }
</script>
