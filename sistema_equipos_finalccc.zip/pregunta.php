<?php
include('./modelo/conexion_bd.php');

$user = $_POST['username'];

$sql = "SELECT usuarios.*, presegu.* 
        FROM usuarios 
        JOIN presegu ON usuarios.id_user = presegu.id_user 
        WHERE usuarios.username='$user'";
$result = mysqli_query($conexion, $sql);
$resultCheck = mysqli_num_rows($result);
?>

<?php
if ($resultCheck > 0) {
    while ($mostrar = mysqli_fetch_array($result)) {
        ?>
        <!--  /*  OPERACION BASE DE DATOS */ -->
        <!DOCTYPE html>
        <html lang="en">
        <?php
            session_start();
            include('./modelo/conexion_bd.php');
            ?>

        <head>
            <meta charset="utf-8">
            <meta content="width=device-width, initial-scale=1.0" name="viewport">

            <title>Recuperacion de contraseña</title>
            <?php include('./includes/header.php'); ?>
            <?php
                if (isset($_SESSION['login_id']))
                    header("location:index.php?page=home");

                ?>
        </head>
        <style>
            body {
                width: 100%;
                height: calc(100%);
                position: fixed;
                top: 0;
                left: 0;
                background-image: url(./assets/img/fondoisp.jpg) !important;
    	        background-size: cover;
                background-repeat: no-repeat;
            }

            main#main {
                width: 100%;
                height: calc(100%);
                display: flex;
            }
        </style>

        <body class="bg-info">
            <main id="main">
                <div class="align-self-center w-100">
                    <!-- <h4 class="text-black text-center"><b>Sistema de Encuesta en Línea</b></h4> -->
                    <div id="login-center" class="row justify-content-center">
                        <div class="card col-md-4">
                            <!-- LOGO-->
                            <img class="avatar" src="./assets/img/iconisp.png" alt="Logo del isp" style="width: 100px; height: 100px; border-radius:50%; margin-left: auto; margin-right: auto;">
                            <h4 class="text-black text-center"><b style="color: black;">Pregunta de seguridad</b></h4>
                            <div class="card-body">
                                <h4 class="text-black text-center"><b style="color: black;"><?php echo $mostrar['pregunta']; ?></b></h4>
                                <form id="login-form" class="needs-validation" action="reiniciarclave.php" method="post" onsubmit="return validarRespuesta()" novalidate>
                                    <div class="form-group">
                                        <label for="respuesta" class="control-label text-dark">Respuesta</label>
                                        <input type="text" id="respuesta" name="respuesta" class="form-control form-control-sm">
                                    </div>
                                    <center>
                                        <button class="btn-sm btn-block btn-wave col-md-4 btn-primary">Ingresar
                                        </button>
                                    </center>
                                    <br>
                                    <br>
                                    <button type="button" class="btn-sm btn-block btn-wave col-md-4 btn-warning" onclick="window.location.href='index.php'">Volver al inicio
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </main>

            <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>
            <script>
                function validarRespuesta() {
                    var respuesta = document.getElementById('respuesta').value;
                    if (respuesta.trim() === '') {
                        alert('Por favor, ingrese su respuesta.');
                        return false; // Evita enviar el formulario si la respuesta está vacía
                    }
                    return true; // Permite enviar el formulario si la respuesta no está vacía
                }
            </script>
            
        </body>

        </html>

        <?php
    }
} else {
    // El correo electrónico no existe, mostrar mensaje de error y redirigir al usuario
    ?>
    <script>
        alert("Email Invalido, intentelo de nuevo");
        window.location.href = "javascript:history.go(-1)";
        document.getElementById("email").value = ""; // Limpia el campo de correo electrónico
    </script>
    <?php
}
?>
