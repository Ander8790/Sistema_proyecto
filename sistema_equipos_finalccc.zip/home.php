<?php

include_once ('./modelo/conexion_bd.php');

// Iniciar la sesión
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['usuario'])) {
    // Si no hay sesión, redirigir al login
    header('Location: login.php');
    exit(); // Asegura que el código posterior no se ejecute
}

include('./includes/header.php');

// include('./includes/topbar.php');
include('./includes/sidebar.php');

// Si la sesión está activa, mostrar el contenido
echo "Bienvenido, " . htmlspecialchars($_SESSION['usuario']) . "!";

echo "conexion realizada";


?>


<a href="/controlador/logout.php">Cerrar Sesión</a>