<?php

include('./modelo/conexion_bd.php');

//echo $_POST['respuesta'];
$respuesta=$_POST['respuesta'];
/*  OPERACION BASE DE DATOS */
$sql = "SELECT usuarios.*, presegu.*
        FROM usuarios
        JOIN presegu ON usuarios.id_user = presegu.id_user
        WHERE presegu.respuesta='$respuesta'";
$result = mysqli_query($conexion, $sql);
$resultCheck = mysqli_num_rows($result);

if ($resultCheck > 0) {
    while ($mostrar = mysqli_fetch_array($result)) {
?>
         <!--  /*  OPERACION BASE DE DATOS */ -->
         <!DOCTYPE html>
         <html lang="en">
         <?php
            session_start();
            include('./modelo/conexion_bd.php');
            ?>

         <head>
             <meta charset="utf-8">
             <meta content="width=device-width, initial-scale=1.0" name="viewport">

             <title>Recuperacion de contraseña</title>
             <?php include('templates/header.php'); ?>
             <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
             <?php
                if (isset($_SESSION['login_id']))
                    header("location:index.php?page=home");

                ?>
         </head>
         <style>
             body {
                 width: 100%;
                 height: calc(100%);
                 position: fixed;
                 top: 0;
                 left: 0;
                 background-image: url(./assets/img/fondoisp.jpg) !important;
    	        background-size: cover;
                background-repeat: no-repeat;
             }

             main#main {
                 width: 100%;
                 height: calc(100%);
                 display: flex;
             }
         </style>

         <body class="bg-info">
             <main id="main">
                 <div class="align-self-center w-100">
                     <!-- <h4 class="text-black text-center"><b>Sistema de Encuesta en Línea</b></h4> -->
                     <div id="login-center" class="row justify-content-center">
                         <div class="card col-md-4">
                             <!-- LOGO-->
                             <img class="avatar" src="./assets/img/iconisp.png" alt="Logo del isp" style="width: 120px; height: 120px; border-radius:50%; margin-left: auto; margin-right: auto;">
                             <h4 class="text-black text-center"><b style="color: black;">Cambiar contraseña</b></h4>
                             <div class="card-body">
                                 <form id="login-form" class="needs-validation" action="/controlador/mod.usuario.pre.php" method="post" novalidate onsubmit="return validarContraseña();">
                                     <input type="hidden" class="form-control form-control-sm" name="username" value="<?php echo $username = $mostrar['username']; ?>">
                                     <div class="form-group">
                                         <label for="clave" class="control-label text-dark">Contraseña</label>
                                         <input type="password" class="form-control form-control-sm" name="clave" id="clave">
                                     </div>
                                     <div class="form-group">
                                         <label for="confirmclave" class="control-label text-dark">Confirmar Contraseña</label>
                                         <input type="password" class="form-control form-control-sm" name="confirmclave" id="confirmclave">
                                     </div>
                                     <center>
                                         <button class="btn-sm btn-block btn-wave col-md-4 btn-primary">
                                             Ingresar
                                         </button>
                                     </center>
                                     <br>
                                     <br>
                                     <button type="button" class="btn-sm btn-block btn-wave col-md-4 btn-warning" onclick="window.location.href='index.php'">Volver al inicio
                                     </button>
                                 </form>
                             </div>
                         </div>
                     </div>
                 </div>
             </main>

             <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

             <script>
                 // Función para validar la contraseña
                 function validarContraseña() {
                     var contraseña = document.getElementById("clave").value;
                     var confirmarContraseña = document.getElementById("confirmclave").value;
                     var mayusculaRegex = /[A-Z]/;
                     var minusculaRegex = /[a-z]/;
                     var caracterEspecialRegex = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;

                     // Verificar longitud mínima
                     if (contraseña.length < 8) {
                         alert("La contraseña debe tener al menos 8 caracteres.");
                         return false;
                     }

                     // Verificar mayúsculas
                     if (!mayusculaRegex.test(contraseña)) {
                         alert("La contraseña debe contener al menos una letra mayúscula.");
                         return false;
                     }

                     // Verificar minúsculas
                     if (!minusculaRegex.test(contraseña)) {
                         alert("La contraseña debe contener al menos una letra minúscula.");
                         return false;
                     }

                     // Verificar caracteres especiales
                     if (!caracterEspecialRegex.test(contraseña)) {
                         alert("La contraseña debe contener al menos un carácter especial.");
                         return false;
                     }

                     // Verificar coincidencia entre las contraseñas
                     if (contraseña !== confirmarContraseña) {
                         alert("Las contraseñas no coinciden.");
                         return false;
                     }

                     return true;
                 }
             </script>

         </body>

         </html>

 <?php }
} else { ?>

     <script>
         alert("Respuesta incorrecta, intentelo de nuevo");

         window.location.href = "javascript:history.go(-1)";;
     </script>

 <?php } ?>
