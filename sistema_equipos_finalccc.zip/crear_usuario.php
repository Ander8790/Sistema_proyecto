<?php session_start();?>



<?php

include("./modelo/conexion_bd.php");
include("./includes/header.php");

include("./includes/sidebar.php");
?>

<div class="col-lg-12">
    <div class="card">
        <div class="card-body">
            <form action="/controlador/procesar_crearuser.php" method="post" style="width: 100%;">
                <div class="row">
                    <!-- Columna Izquierda -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="" class=""> <strong>Nombre: </strong></label>
                            <input type="text" name="txtNombre" class="form-control form-control-sm" required>
                        </div>
                        <div class="form-group">
                            <label for="" class=""> <strong>Apellido: </strong></label>
                            <input type="text" name="txtApellido" class="form-control form-control-sm" required>
                        </div>
                        <div class="form-group">
                            <label for="" class=""> <strong>Usuario: </strong></label>
                            <input type="text" name="txtUsuario" class="form-control form-control-sm" required>
                        </div>
                        <div class="form-group">
                            <label for="" class=""><strong>Contraseña: </strong></label>
                            <div class="d-flex align-items-center">
                                <input type="password" id="txtContraseña" name="txtContraseña" class="form-control form-control-sm" required>
                                <button type="button" id="togglePassword" class="btn btn-outline-secondary btn-sm ml-2">
                                    <i class='bx bx-hide'></i>
                                </button>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="" class=""><strong>Verificar contraseña: </strong></label>
                            <div class="d-flex align-items-center">
                                <input type="password" id="txtCContraseña" name="txtCContraseña" class="form-control form-control-sm" required>
                                <button type="button" id="toggleCPassword" class="btn btn-outline-secondary btn-sm ml-2">
                                    <i class='bx bx-hide'></i>
                                </button>
                            </div>
                            <small id="pass_match" data-status=''></small>
                        </div>
                    </div>
                    <!-- Columna Derecha -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="" class="control-label">Rol de Usuario</label>
                            <select name="type" id="type" class="form-control">
                                <option value="3" <?php echo isset($type) && $type == 3 ? 'selected' : '' ?>>Secretaria</option>
                                <option value="2" <?php echo isset($type) && $type == 2 ? 'selected' : '' ?>>Odontólogo</option>
                                <option value="1" <?php echo isset($type) && $type == 1 ? 'selected' : '' ?>>Administrador</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="" class=""> <strong>Cédula: </strong></label>
                            <input type="text" name="txtCedula" class="form-control form-control-sm" required>
                        </div>
                        <div class="form-group">
                            <label for="lettersOnly" class="control-label">Pregunta de Seguridad <strong style="color: red;">*</strong></label>
                            <input type="text" name="txtPregunta" id="lettersOnly" class="form-control form-control-sm" required value="<?php echo isset($pregunta) ? $pregunta : '' ?>">
                        </div>
                        <div class="form-group">
                            <label for="" class="control-label">Respuesta de Seguridad <strong style="color: red;">*</strong></label>
                            <input type="text" name="txtRespuesta" class="form-control form-control-sm" required value="<?php echo isset($respuesta) ? $respuesta : '' ?>">
                        </div>
                    </div>
                </div>
                <hr>
                <div class="col-lg-12 text-right justify-content-center d-flex">
                    <button class="btn btn-primary mr-2">Guardar</button>
                    <button class="btn btn-secondary" type="button" onclick="location.href = '/usuarios.php'">Cancelar</button>
                </div>
            </form>
        </div>
    </div>
</div>



<?php
include("./includes/footer.php")
?>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> <!-- Incluye jQuery -->
<script>
    $('[name="txtContraseña"], [name="txtCContraseña"]').on('keyup', function () {
        var pass = $('[name="txtContraseña"]').val();
        var cpass = $('[name="txtCContraseña"]').val();
        
        if (cpass === '' || pass === '') {
            $('#pass_match').attr('data-status', '').html(''); // Limpia si están vacíos
        } else {
            if (cpass === pass) {
                $('#pass_match').attr('data-status', '1').html('<i class="text-success">Contraseñas Coinciden</i>');
            } else {
                $('#pass_match').attr('data-status', '2').html('<i class="text-danger">Contraseñas no Coinciden</i>');
            }
        }
    });





    // visibilidad de la pass

  // Función para alternar la visibilidad de las contraseñas
  function togglePasswordVisibility(inputId, button) {
        const passwordField = document.getElementById(inputId);
        const icon = button.querySelector('i');
        if (passwordField.type === "password") {
            passwordField.type = "text"; // Mostrar contraseña
            icon.classList.remove('bx-hide');
            icon.classList.add('bx-show');
        } else {
            passwordField.type = "password"; // Ocultar contraseña
            icon.classList.remove('bx-show');
            icon.classList.add('bx-hide');
        }
    }

    // Asignar eventos a los botones
    document.getElementById('togglePassword').addEventListener('click', function () {
        togglePasswordVisibility('txtContraseña', this);
    });

    document.getElementById('toggleCPassword').addEventListener('click', function () {
        togglePasswordVisibility('txtCContraseña', this);
    });
</script>