<?php session_start();?>



<?php
    include ("./modelo/conexion_bd.php");
    include("./includes/header.php");
    // include("./includes/sidebar.php");

    // Obtención del id del usuario desde la URL
    $id = $_GET["id"];

    // Consulta para obtener los datos del usuario
    $query = ("SELECT * FROM usuarios WHERE id_user='$id'");
    $result = $conexion->query($query);

    if ($result === false) {
        die("Error en la consulta: " . $conexion->error);
    }

    // Obtener la información del usuario
    $row = $result->fetch_assoc();

    // Obtener la pregunta y la respuesta de la tabla de seguridad
    $pregunta_query = ("SELECT pregunta, respuesta FROM presegu WHERE id_user='$id'");
    $pregunta_result = $conexion->query($pregunta_query);
    $pregunta_row = $pregunta_result->fetch_assoc();
?>

<body>
    <div class="tabla">
        <form action="/controlador/procesar_editar.php" method="post">
            <input type="hidden" value="<?php echo $row['id_user']; ?>" name="txtID">

            <div class="form-control">
                <label>Nombre</label>
                <input type="text" value="<?php echo $row['nombre']; ?>" name="txtNombre" class="form-control form-control-sm">
            </div>
            <div class="form-control">
                <label>Apellido</label>
                <input type="text" value="<?php echo $row['apellido']; ?>" name="txtApellido" class="form-control form-control-sm">
            </div>
            <div class="form-control">
                <label>Usuario</label>
                <input type="text" value="<?php echo $row['username']; ?>" name="txtUsuario" class="form-control form-control-sm">
            </div>
            <div class="form-control">
                <label>Contraseña</label>
                <input type="text" value="" name="txtContraseña" class="form-control form-control-sm">
            </div>

            <div class="form-group">
                <label for="" class="control-label">Rol de Usuario</label>
                <select name="type" id="type" class="form-control">
                    <option value="3" <?php echo ($row['id_rol'] == 3) ? 'selected' : ''; ?>>Secretaria</option>
                    <option value="2" <?php echo ($row['id_rol'] == 2) ? 'selected' : ''; ?>>Odontólogo</option>
                    <option value="1" <?php echo ($row['id_rol'] == 1) ? 'selected' : ''; ?>>Administrador</option>
                </select>
            </div>

            <div class="form-group">
                <label for="lettersOnly" class="control-label">Cédula</label>
                <input type="text" value="<?php echo $row['cedula']; ?>" name="txtCedula" class="form-control form-control-sm" required>
            </div>

            <div class="form-group">
                <label for="lettersOnly" class="control-label">Pregunta de Seguridad <strong style="color: red;">*</strong></label>
                <input type="text" name="txtPregunta" id="lettersOnly" class="form-control form-control-sm" required value="<?php echo isset($pregunta_row['pregunta']) ? $pregunta_row['pregunta'] : ''; ?>">
            </div>

            <div class="form-group">
                <label for="" class="control-label">Respuesta de Seguridad <strong style="color: red;">*</strong></label>
                <input type="text" name="txtRespuesta" class="form-control form-control-sm" required value="<?php echo isset($pregunta_row['respuesta']) ? $pregunta_row['respuesta'] : ''; ?>">
            </div>

            <div class="col-lg-12 text-right justify-content-center d-flex">
                <input type="submit" value="Actualizar" id="" class="btn btn-primary mr-2">
                <button class="btn btn-secondary" type="button" onclick="location.href = '/usuarios.php'">Cancelar</button>
            </div>
        </form>
    </div>

<?php
    include("./includes/footer.php");
?>

</body>
</html>
