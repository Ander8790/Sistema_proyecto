<!DOCTYPE html>
<?php

// Verificar si el usuario está autenticado
if (!isset($_SESSION['usuario'])) {
    // Si no hay sesión, redirigir al login
    header('Location: login.php');
    exit(); // Asegura que el código posterior no se ejecute
}
?>


<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" href="./assets/img/iconisp.png">
  
  <title>Document</title>
</head>
<body>
  
<?php
  // include "./login.php";
?>

</body>
</html>